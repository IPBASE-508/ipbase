define({
  "name": "ipbase 2019 - API",
  "version": "0.1.3",
  "description": "The back font API doc",
  "title": "ipbase 2019 API",
  "url": "https://zengtianyi.top/ipbase",
  "sampleUrl": false,
  "defaultVersion": "0.0.0",
  "apidoc": "0.3.0",
  "generator": {
    "name": "apidoc",
    "time": "2019-05-19T17:57:31.137Z",
    "url": "http://apidocjs.com",
    "version": "0.17.6"
  }
});
