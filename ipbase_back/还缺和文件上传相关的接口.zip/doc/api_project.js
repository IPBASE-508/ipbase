define({
  "name": "obooAmazon - API",
  "version": "0.1.0",
  "description": "The back font API doc",
  "title": "obooAmazon API",
  "url": "https://zengtianyi.top/ipbase",
  "sampleUrl": false,
  "defaultVersion": "0.0.0",
  "apidoc": "0.3.0",
  "generator": {
    "name": "apidoc",
    "time": "2019-05-09T06:38:53.560Z",
    "url": "http://apidocjs.com",
    "version": "0.17.6"
  }
});
